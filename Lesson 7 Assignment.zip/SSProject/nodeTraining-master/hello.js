console.log('Hi');


  setTimeout(() => {
            console.log("there !");
  }, 5000);

// setTimeout(function(){
//     console.log("there !");
// }, 5000);

